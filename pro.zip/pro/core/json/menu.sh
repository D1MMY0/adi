#!/bin/bash/
clear
cd core
cd json
bash logo.sh
sleep 1
cd ..
cd lib
bash man
echo ""
read -p $'\e[1;5m[\e[0m\e[1;5m⚡\e[0m\e[1;5m]\e[0m\e[1;96m What You Want to Select  \e[1;5m  > > > \e[0m' ABHI
if [[ $ABHI == 1  ]];then
echo " DOWNOLOAD NEXT TIME APP IS CRASHED " | lolcat
elif [[ $ABHI == 2 ]];then
clear
echo -e '\033[32;5m Frist Check your internet Connection \033[0m\n'
cd xdg-open
php CMQyGnfN
echo          "          HAPPY HACKING        " | lolcat
echo ""
elif [[ $ABHI == 3 ]];then
xdg-open 'https://mega.nz/folder/dAwWDKLS#_sJMzYUE3QXzU_ah4tsz2Q'
sleep 3
elif [[ $ABHI == 4 ]];then
echo ""
echo " [1] Mod VPN Life Time Free " | lolcat
echo ""
echo " [2] Windows 10 RDP " | lolcat
echo ""
echo " [3] Socks5 for firefox " | lolcat
echo ""
echo " [4] Vps server free " | lolcat
echo ""
echo " [0] Exit 📴 " | lolcat
echo ""
read -p $'\e[1;96m[\e[0m\e[1;5m⚡\e[0m\e[1;96m]\e[0m\e[1;96m What You Want to Select \e[1;5m > > > \e[0m' GIT
if [[ $GIT == 1 ]];then
echo " Download next time " | lolcat
elif [[ $GIT == 2 ]];then
sleep 5
echo " Your internet not work properly " | lolcat
elif [[ $GIT == 3 ]];then
cd ~
curl https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt -o socks5.txt
sleep 3
clear
echo " 5000 proxy download " 
curl https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt -o proxybyD1my.txt
sleep 3
clear
echo " socks5 Download save in your home " | lolcat
curl https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt -o socks4.txt
sleep 3
curl https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt -o proxy992.txt
echo " proxy and socks file downloded " | lolcat
echo " Type cd ~ and check " | lolcat 
elif [[ $GIT == 4 ]];then
sleep 1
elif [[ $GIT == 0 ]];then
exit 1
else
echo ""
echo -e '\e[1;96m[\e[0m\e[1;5m⚡\e[0m\e[1;96m]\e[0m\e[1;32m You Are Select LOL 😆: \e[0m'
echo ""
echo "  BYE COME TO NEXT TIME " | lolcat
echo ""
fi
elif [[ $ABHI == 5 ]] ;then
echo ""
echo " {A} English " | lolcat
echo ""
echo " {B} Hindi " | lolcat
echo ""
read -p $'\033[36;5m Select Language  >>> \033[0m\n'  options
if [[ $options == A || $options == a ]];then
termux open url https://mega.nz/folder/dAwWDKLS#_sJMzYUE3QXzU_ah4tsz2Q
sleep 1
elif [[ $options == B || $options == b ]];then
xdg-open 'https://mega.nz/folder/FyZgCDKR#4HDbQSY1KNoD00oEe4jlew'
sleep 1
else
echo   "        📴 YOU SELECT LOL 😆😆 !! " | lolcat 
sleep 2
bash inter.sh
fi
elif [[ $ABHI == 6 ]];then
sleep 3
elif [[ $ABHI == 7 ]];then
sleep 2
elif [[ $ABHI == 0 ]];then
clear
exit 1
else
sleep 1
echo ""
echo ""
echo -e '\033[38;3m            -:  ^^O̷ ꦿ⃕O̷↬ۦོ͢✰͢⇣͢✘͢͢⁦ WRONG OPTION PLEASE CHECK ☑!:- \033[0m\n'
echo ""
echo -e '\033[32;3m            -:  ^^O̷ ꦿ⃕O̷↬ۦོ͢✰͢⇣͢✘͢͢⁦ BYY TNX FOR USING  !:- \033[0m\n'
echo ""
fi







