#!/bin/bash
#code by D1MY
pkg install wget
pkg install python
pkg install lolcat
pkg install php
pkg install lolcat
clear
echo " >>>>>>>>>>>>>>>>>>>>>> " | lolcat
echo "
██████╗ ██████ ██╗   ██╗██████╗ ██╗ ████████╗
██╔══██ ██╔════██║   ██ ██╔═══██ ██║ ╚══██╔══╝
██████╔ █████╗ ██║   ██ ██║   ██ ██║    ██║   
██╔══██ ██╔══╝ ╚██╗ ██╔ ██║   ██ ██║    ██║   
██║  ██ ███████╗╚████╔╝╚██████╔ █████████║   
╚═╝  ╚═╚══════╝ ╚═══╝  ╚═════╝ ╚══════╚═╝ " | lolcat   
                                           
sleep 1
clear
echo "
 ██████╗██╗   ██╗██╗  ████████╗
██╔════╝██║   ██║██║  ╚══██╔══╝
██║     ██║   ██║██║     ██║   
██║     ██║   ██║██║     ██║   
╚██████╗╚██████╔╝███████╗██║   
 ╚═════╝ ╚═════╝ ╚══════╝╚═╝   " | lolcat
sleep 1
                               
clear
echo " wait >>>>>>>>>>> " | lolcat
sleep 2
echo " open in 30 seconds " | lolcat
sleep 2
echo " Your System Is Slow >>>> " | lolcat
sleep 1
cd core/
clear
echo " wait >>>>>>>>>>> " | lolcat
sleep 2
echo " open in 20 seconds " | lolcat
sleep 2
echo " Your Machine Is Slow 🔱 >>>> " | lolcat
sleep 1
./Carding.sh




